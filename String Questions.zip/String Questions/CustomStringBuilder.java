package com.trial;

/*Q2.Build a simplified version of the StringBuilder class. 
 	Your custom class should support basic string manipulation operations such as:
	Appending a string.
	Inserting a string at a specific index.
	Deleting a portion of the string.
	
	convert to character array 
	manipulate then convert back to String
	*/
public class CustomStringBuilder {
	
	String s1;
	
	public CustomStringBuilder(String initialString)
	{
		s1 = initialString;
	}
	public void append(String stringToAppend)
	{
		char[] array1 = s1.toCharArray();
        char[] array2 = stringToAppend.toCharArray();
        
        // Create a new char array with a size equal to the sum of lengths
        char[] resultArray = new char[array1.length + array2.length];
        
        // Copy elements from array1 to resultArray
        System.arraycopy(array1, 0, resultArray, 0, array1.length);
        
        // Copy elements from array2 to resultArray
        System.arraycopy(array2, 0, resultArray, array1.length, array2.length);
        
        // Convert the resultArray to String for printing
        s1 = new String(resultArray);
	}
	
	public void insert(String stringToInsert, int insertIndex)
	{
		char[] originalArray = s1.toCharArray();
        
        // Char array to insert
        char[] arrayToInsert = stringToInsert.toCharArray();
        
        // Index to insert arrayToInsert into originalArray
        // The index after 'o' in "Hello"
        
        // Create a new char array with a size equal to the sum of lengths
        char[] resultArray = new char[originalArray.length + arrayToInsert.length];
        
        // Copy elements from originalArray to resultArray before the insert index
        System.arraycopy(originalArray, 0, resultArray, 0, insertIndex);
        
        // Copy elements from arrayToInsert to resultArray starting at the insert index
        System.arraycopy(arrayToInsert, 0, resultArray, insertIndex, arrayToInsert.length);
        
        // Copy remaining elements from originalArray to resultArray after the insert index
        System.arraycopy(originalArray, insertIndex, resultArray, insertIndex + arrayToInsert.length, originalArray.length - insertIndex);
        
        // Convert the resultArray to String for printing
        s1 = new String(resultArray);
        
	}
	public void deletePortion(int startIndex, int endIndex)
	{
		char[] originalArray = s1.toCharArray();
  
        // Calculate the length of the section to delete
        int deleteLength = endIndex - startIndex;
        
        // Create a new char array with a size equal to the original array minus the section to delete
        char[] resultArray = new char[originalArray.length - deleteLength];
        
        // Copy elements from originalArray to resultArray before the delete index
        System.arraycopy(originalArray, 0, resultArray, 0, startIndex);
        
        // Copy remaining elements from originalArray to resultArray after the deleted section
        System.arraycopy(originalArray, endIndex, resultArray, startIndex, originalArray.length - endIndex);
        
        // Convert the resultArray to String for printing
        s1 = new String(resultArray);

	}
	public String toString()
	{
		return s1;
	}
	
	public static void main(String[] arg)
	{
		CustomStringBuilder stringbuilder= new CustomStringBuilder("abc");
		stringbuilder.append("def");
		System.out.println(stringbuilder);
		
		stringbuilder.insert("123", 0);
		System.out.println(stringbuilder);
		
		stringbuilder.deletePortion(0, 3);
		System.out.println(stringbuilder);
		
	}
	
}
