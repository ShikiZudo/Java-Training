package com.trial;

/*Q4.URL Parser and Builder:Create a class called URLParser 
that parses a URL into its components 
(protocol, host, path, query parameters, etc.). 
Additionally, implement a class named URLBuilder that 
constructs a URL from its components*/
import java.util.HashMap;
import java.util.Map;

public class URLBuilder {
	private String protocol;
	private String host;
	private String path;
	private Map<String, String> queryParameters;

	public URLBuilder() {
		this.queryParameters = new HashMap<>();
	}

	public URLBuilder setProtocol(String protocol) {
		this.protocol = protocol;
		return this;
	}

	public URLBuilder setHost(String host) {
		this.host = host;
		return this;
	}

	public URLBuilder setPath(String path) {
		this.path = path;
		return this;
	}

	public URLBuilder addQueryParameter(String key, String value) {
		this.queryParameters.put(key, value);
		return this;
	}

	public String build() {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(protocol).append("://").append(host).append(path);

		if (!queryParameters.isEmpty()) {
			stringBuilder.append("?");

			for (Map.Entry<String, String> entry : queryParameters.entrySet()) {
				stringBuilder.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
			}

			stringBuilder.deleteCharAt(stringBuilder.length() - 1); // Remove the trailing "&"
		}

		return stringBuilder.toString();
	}

	public static void main(String[] args) {
		URLBuilder urlBuilder = new URLBuilder().setProtocol("https").setHost("www.example.com").setPath("/path")
				.addQueryParameter("param1", "value1").addQueryParameter("param2", "value2");

		String builtURL = urlBuilder.build();
		System.out.println("Built URL: " + builtURL);
	}
}