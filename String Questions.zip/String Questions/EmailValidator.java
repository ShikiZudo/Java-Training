package com.trial;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/*Q1.Write a program to validate if a given string is a 
valid email address.
abc@gmail.com regex?? no multiple @
no multiple . dot allowed
@ before . 
something before @, 
something between @ and .
something after .*/


public class EmailValidator {
	public static boolean sol(String email)
	{
		boolean res = false;
		String regex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
                "[a-zA-Z0-9_+&*-]+)*@" + 
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
                "A-Z]{2,7}$"; 
		Pattern pattern = Pattern.compile(regex); 
		 
		res= pattern.matcher(email).matches();
		return res;
	}
	
	public static void main(String[] arg)
	{
		String input1="abc@gmail.com";
		String input2="abc@gmail";
		String input3 = "@gmail.com";
		String input4 = "@gmail";
		String input5="writing.geeksforgeeks.org";
		
		List<String> email_list = new ArrayList<String>();
		email_list.add(input1);
		email_list.add(input2);
		email_list.add(input3);
		email_list.add(input4);
		email_list.add(input5);
		
		for(String email : email_list)
		{
			System.out.println(email+": "+sol(email));
		}
		
	}
	
	
}
