package com.trial;
/*Q3. Create a class called StringSearchEngine that allows users to search 
for a substring in a given text. The class should have methods for:

Finding all occurrences of a substring.

Return start and end of the matched substrings in the original text.*/

import java.util.ArrayList;
import java.util.List;

public class StringSearchEngine {

	private String originalText;

	public StringSearchEngine(String originalText) {
		this.originalText = originalText;
	}

	public List<MatchedSubstring> findAllOccurrences(String substring) {
		List<MatchedSubstring> matches = new ArrayList<>();
		int index = originalText.indexOf(substring);

		while (index != -1) {
			int endIndex = index + substring.length() - 1;
			matches.add(new MatchedSubstring(index, endIndex));
			index = originalText.indexOf(substring, index + 1);
		}

		return matches;
	}

	public static class MatchedSubstring {
		private int startIndex;
		private int endIndex;

		public MatchedSubstring(int startIndex, int endIndex) {
			this.startIndex = startIndex;
			this.endIndex = endIndex;
		}

		public int getStartIndex() {
			return startIndex;
		}

		public int getEndIndex() {
			return endIndex;
		}
	}

	public static void main(String[] args) {
		StringSearchEngine searchEngine = new StringSearchEngine("Hello, Hello, World!");

		String substringToSearch = "Hello";
		List<MatchedSubstring> occurrences = searchEngine.findAllOccurrences(substringToSearch);

		System.out.println("Occurrences of '" + substringToSearch + "':");
		for (MatchedSubstring occurrence : occurrences) {
			System.out
					.println("Start Index: " + occurrence.getStartIndex() + ", End Index: " + occurrence.getEndIndex());
		}
	}
}
