package com.trial;
/*Q4.URL Parser and Builder:Create a class called URLParser 
that parses a URL into its components 
(protocol, host, path, query parameters, etc.). 
Additionally, implement a class named URLBuilder that 
constructs a URL from its components*/

import java.util.HashMap;
import java.util.Map;

public class URLParser {
	private String url;

	public URLParser(String url) {
		this.url = url;
	}

	public String getProtocol() {
		return url.split("://")[0];
	}

	public String getHost() {
		String[] parts = url.split("://")[1].split("/", 2);
		return parts[0];
	}

	public String getPath() {
		String[] parts = url.split("://")[1].split("/", 2);
		return (parts.length > 1) ? "/" + parts[1] : "/";
	}

	public Map<String, String> getQueryParameters() {
		Map<String, String> queryParams = new HashMap<>();
		
		String[] parts = url.split("\\?");

		String[] params = parts[1].split("&");

		for (String param : params) {
			String[] keyValue = param.split("=");

			queryParams.put(keyValue[0], keyValue[1]);

		}

		return queryParams;

	}

	public static void main(String[] args) {
		String exampleURL = "https://www.example.com/path?param1=value1&param2=value2";

		URLParser urlParser = new URLParser(exampleURL);

		System.out.println("Protocol: " + urlParser.getProtocol());
		System.out.println("Host: " + urlParser.getHost());
		System.out.println("Path: " + urlParser.getPath());
		System.out.println("Query Parameters: " + urlParser.getQueryParameters());
	}
}


