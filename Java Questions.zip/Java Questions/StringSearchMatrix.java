package com.trial;
// find word in 2d string matrix
public class StringSearchMatrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//brute force
		String[][] matrix = { { "apple", "orange", "banana" }, { "grape", "apple", "kiwi" },
				{ "pear", "melon", "apple" } };

		String targetWord = "apple";
		//findOccurrences(matrix, wordToSearch);
		int rows = matrix.length;
		int cols = matrix[0].length;
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				if (matrix[i][j].equals(targetWord)) {
					System.out.println("Found at position (" + i + ", " + j + ")");
				}
			}
		}
	}


}
