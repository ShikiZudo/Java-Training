package com.trial;
import java.util.ArrayList;
public class FindPrimeInReverseNumber {
	public static int rev(int number)
	{
		int reverse = 0;
		while(number != 0)   
		{  
			int remainder = number % 10;  
			reverse = reverse * 10 + remainder;  
			number = number/10;  
		} 
		return reverse;
	}
	public static ArrayList<String> sol(int n)
	{
		ArrayList<String> res = new ArrayList<String>();
		
		while(n>0)
		{
			int rem = n%10;	//extracting last digit
			
			switch(rem) {
			case 2:
				res.add("Two ");
				break;
			case 3:
				res.add("Three ");
				break;
			case 5:
				res.add("Five ");
				break;
			case 7:
				res.add("Seven ");
				break;
			default:
				break;
			}
			n=n/10;
		}
		return res;
	}
	public static void main(String[] args) {
		
		int num = 257891;
		int rev = rev(num);
		System.out.println("Rev:"+rev);
		ArrayList<String> res=sol(num);
		res.forEach(it->System.out.println(it)); // print 
		
	}
	
}
