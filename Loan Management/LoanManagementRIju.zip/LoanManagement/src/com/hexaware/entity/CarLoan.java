package com.hexaware.entity;

import java.util.Scanner;

class CarLoan extends Loan{
	public CarLoan(int loanid, int cid, int pamt, float irate, int lterm, String ltype, String lstatus, String carModel,
			int carValue) {
		super(loanid, cid, pamt, irate, lterm, ltype, lstatus);
		this.carModel = carModel;
		this.carValue = carValue;
	}
	public CarLoan() {
		// TODO Auto-generated constructor stub
	}
	public String getCarModel() {
		return carModel;
	}
	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}
	public int getCarValue() {
		return carValue;
	}
	public void setCarValue(int carValue) {
		this.carValue = carValue;
	}
	
	public String toString(){//overriding the toString() method  
		  return carModel+" "+carValue;  
	}
	
	String carModel;
	int carValue;
	
	public void addCl()
	{
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Car Model");
		sc.nextLine(); // Consume the newline character
		setCarModel(sc.nextLine());
		
		System.out.println("Enter Car Value");
		setCarValue(sc.nextInt());
		
		
	}
}


