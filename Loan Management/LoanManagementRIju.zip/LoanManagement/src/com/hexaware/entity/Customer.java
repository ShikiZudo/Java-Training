package com.hexaware.entity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

import com.hexaware.util.DBUtil;

public class Customer {

		// TODO Auto-generated method stub
		public Customer(int cid, String name, String email, String pno, String add, int cscore) {
		super();
		this.cid = cid;
		this.name = name;
		this.email = email;
		this.pno = pno;
		this.add = add;
		this.cscore = cscore;
		}
		public Customer() {
			// TODO Auto-generated constructor stub
		}
		
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getPno() {
			return pno;
		}
		public void setPno(String pno) {
			this.pno = pno;
		}
		public String getAdd() {
			return add;
		}
		public void setAdd(String add) {
			this.add = add;
		}
		public int getCscore() {
			return cscore;
		}
		public int getCid() {
			return cid;
		}
		public void setCid(int cid) {
			this.cid = cid;
		}
		public void setCscore(int cscore) {
			this.cscore = cscore;
		}
		
		public String toString(){//overriding the toString() method  
			  return cid+" "+name+" "+email+" "+pno+" "+add+" "+cscore;  
		}
		private int cid;
		private String name;
		private String email;
		private String pno;
		private String add;
		private int cscore;
	
		public void addCus() throws Exception
		{
			
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Enter Customer ID");
			this.cid = sc.nextInt();
		
			sc.nextLine(); // Consume the newline character

			System.out.println("Enter Customer name");
			this.name = sc.nextLine();

			System.out.println("Enter Customer email");
			this.email = sc.nextLine();

			System.out.println("Enter Customer phone number");
			this.pno = sc.nextLine();

			System.out.println("Enter Customer address");
			this.add  = sc.nextLine();

			System.out.println("Enter Customer credit score");
			this.cscore = sc.nextInt();

			
			
			Connection con = DBUtil.getDBConn();
			
			PreparedStatement ps;

			String sql = "Insert into customer values(" + cid + ",'" + name + "','" + email + "','" + pno + "','" + add
					+ "'," + cscore + ")";
			ps = con.prepareStatement(sql);
			ps.executeUpdate();
			
			System.out.println("Customer added successfully");
			
		}
}
