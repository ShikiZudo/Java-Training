package com.hexaware.entity;

import java.util.Scanner;

class HomeLoan extends Loan{
	public HomeLoan(int loanid, int cid, int pamt, float irate, int lterm, String ltype, String lstatus,
			String propertyAddress, int propertyValue) {
		super(loanid, cid, pamt, irate, lterm, ltype, lstatus);
		this.propertyAddress = propertyAddress;
		this.propertyValue = propertyValue;
	}
	public HomeLoan() {
		// TODO Auto-generated constructor stub
	}
	public String getPropertyAddress() {
		return propertyAddress;
	}
	public void setPropertyAddress(String propteryAddress) {
		this.propertyAddress = propteryAddress;
	}
	public int getPropertyValue() {
		return propertyValue;
	}
	public void setPropertyValue(int propertyValue) {
		this.propertyValue = propertyValue;
	}
	
	public String toString(){//overriding the toString() method  
		  return propertyAddress+" "+propertyValue;  
	}
	
	String propertyAddress;
	int propertyValue;
	
	public void addHl()
	{
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Property address");
		sc.nextLine(); // Consume the newline character
		setPropertyAddress(sc.nextLine());
		
		System.out.println("Enter Property Value");
		setPropertyValue(sc.nextInt());
		
		
	}
}