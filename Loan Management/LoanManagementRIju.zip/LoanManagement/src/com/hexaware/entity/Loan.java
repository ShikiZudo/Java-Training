package com.hexaware.entity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

import com.hexaware.util.DBUtil;

public class Loan {
	public Loan(int loanid, int cid, int pamt, float irate, int lterm, String ltype, String lstatus) {
		super();
		this.loanid = loanid;
		this.cid = cid;
		this.pamt = pamt;
		this.irate = irate;
		this.lterm = lterm;
		this.ltype = ltype;
		this.lstatus = lstatus;
	}
	public Loan() {
		// TODO Auto-generated constructor stub
	}
	public int getLoanid() {
		return loanid;
	}
	public void setLoanid(int loanid) {
		this.loanid = loanid;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public int getPamt() {
		return pamt;
	}
	public void setPamt(int pamt) {
		this.pamt = pamt;
	}
	public float getIrate() {
		return irate;
	}
	public void setIrate(float irate) {
		this.irate = irate;
	}
	public int getLterm() {
		return lterm;
	}
	public void setLterm(int lterm) {
		this.lterm = lterm;
	}
	public String getLtype() {
		return ltype;
	}
	public void setLtype(String ltype) {
		this.ltype = ltype;
	}
	public String getLstatus() {
		return lstatus;
	}
	public void setLstatus(String lstatus) {
		this.lstatus = lstatus;
	}
	public String toString(){//overriding the toString() method  
		  return loanid+" "+cid+" "+pamt+" "+irate+" "+lterm+" "+ltype+" "+lstatus; 
		 }
	
	int loanid;
	int cid;
	int pamt;
	float irate;
	int lterm;
	String ltype;
	String lstatus;
	
	public void addLoan() throws Exception
	{
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Loan ID:");
		setLoanid(sc.nextInt()); 
		
		System.out.println("Enter Customer ID:");
		setCid(sc.nextInt());
		
		System.out.println("Enter Principal Amount:");
		setPamt(sc.nextInt());
		
		System.out.println("Enter Interest Rate: ");
		setIrate(sc.nextFloat());
		
		System.out.println("Enter Loan Term in years: ");
		setLterm(sc.nextInt());
	
		System.out.println("Enter loan type: Press 1 for Home Loan, Press 2 for Car Loan");
		int pr = sc.nextInt();
		
		HomeLoan hl = new HomeLoan();
		CarLoan cl = new CarLoan();

		if(pr==1)
		{
			System.out.println("You have pressed 1: Home Loan:");
			setLtype("HomeLoan");
			
			hl.addHl();
			
			
		}
		else if(pr==2)
		{
			System.out.println("You have pressed 2: Car Loan:");
			setLtype("CarLoan");
			
			cl.addCl();
			
		}
		
		
		
		// set loan status as pending ... loan status can be pending, rejected or approved
		this.setLstatus("Pending");
		 
		// get confirmation from user
		System.out.println("Confirmation msg: Do you want to apply? enter 1 for Yes and 0 for No");
		int conf = sc.nextInt();
		
		if(conf==1) {
			
			
			Connection con = DBUtil.getDBConn();
			
			String sql2 = null ;
	        PreparedStatement ps,ps2;
			
			String sql = "Insert into loan values("+getLoanid()+","+getCid()+","+getPamt()+","+getIrate()+","+getLterm()+",'"+getLtype()+"','"+getLstatus()+"')";
			ps = con.prepareStatement(sql);
	        ps.executeUpdate();
	        
	        if(pr==1)
	        {
	        //home loan
	        sql2 = "Insert into  homeloan values("+getLoanid()+","+getCid()+",'"+hl.getPropertyAddress()+"',"+hl.getPropertyValue()+")";
			
	        }
	        if(pr==2) {
	        	//car loan
		        sql2 = "Insert into carloan values("+getLoanid()+","+getCid()+",'"+cl.getCarModel()+"',"+cl.getCarValue()+")";
				
	        }
	        ps2 = con.prepareStatement(sql2);
	        ps2.executeUpdate();
	        
	        System.out.println("Applied for Loan successfully!!");
		}
		else
			System.out.println("Loan apply cancelled");
	
	}

}





