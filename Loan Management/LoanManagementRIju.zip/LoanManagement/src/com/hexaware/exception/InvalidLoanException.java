package com.hexaware.exception;

@SuppressWarnings("serial")
public class InvalidLoanException extends Exception{
	
	public InvalidLoanException() {
        System.out.println("Invalid Loan ID");
    }
}
