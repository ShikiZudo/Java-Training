package com.hexaware.dao;

import com.hexaware.entity.Customer;
import com.hexaware.entity.Loan;
import com.hexaware.repo.ILoanRepository;
import com.hexaware.repo.ILoanRepositoryImpl;
import com.hexaware.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class LoanManagement {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		/*
		 * main method to simulate the loan management system. Allow the user to
		 * interact with the system by entering choice from menu such as "applyLoan",
		 * "getAllLoan", "getLoan", "loanRepayment", "exit.
		 */
		
		
		// NOTES: you first need to add the customer then you can apply 
		// for loan.
		

		int choice = 0;

		while (choice >= 0) {

			System.out.println("-----------------------------------------------------------------");
			System.out.println("Welcome to Loan Management System");
			System.out.println("Enter the corresponding numbers to access the Menu options.");
			System.out.println("-----------------------------------------------------------------");
			System.out.println("1: Apply for loan");
			System.out.println("2: Get all loan");
			System.out.println("3: Get loan using LoanID");
			System.out.println("4: Loan Repayment");
			System.out.println("5: Calculate Interest");
			System.out.println("6: Calculate EMI");
			System.out.println("7: Calculate Loan Status");
			System.out.println("8: Add Customer");
			System.out.println("9: Exit");
			System.out.println("-----------------------------------------------------------------");
			
			Scanner sc = new Scanner(System.in);
			choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("You have entered 1: Apply for Loan");
				Loan l = new Loan();
				ILoanRepositoryImpl il0 = new ILoanRepositoryImpl();
				il0.applyLoan(l);

				
				break;
				

			case 2:
				System.out.println("You have entered 2: Get all loan");
				ILoanRepositoryImpl il1 = new ILoanRepositoryImpl();
				il1.getAllLoan();
				break;
				

			case 3:
				System.out.println("You have entered 3: Get loan using LoanID");
				System.out.println("Enter the required loan ID: ");
				int lid = sc.nextInt();
				ILoanRepositoryImpl il2 = new ILoanRepositoryImpl();
				il2.getLoanById(lid);
				break;
				

			case 4:
				System.out.println("You have entered 4: Loan Repayment");

				System.out.println("Enter the required loan ID.");
				int lid2 = sc.nextInt();
				System.out.println("Enter the required Amount.");
				float amt = sc.nextInt();
				
				ILoanRepositoryImpl il3 = new ILoanRepositoryImpl();
				int no_of_emi = il3.loanRepayment(lid2, amt);
				System.out.println("The no of emi required is : " + no_of_emi);

				break;
				

			case 5:
				System.out.println("You have entered 5: Calculate Interest");
				System.out.println("Enter Loan ID: ");
				int lid4 = sc.nextInt();
				
				ILoanRepositoryImpl il4 = new ILoanRepositoryImpl();
				System.out.println("The interest for Loan ID: " + lid4 + " is " + il4.calculateInterest(lid4));

				break;
				

			case 6:
				System.out.println("You have entered 6: Calculate EMI");
				System.out.println("Enter Loan ID: ");
				int lid6 = sc.nextInt();
				
				ILoanRepositoryImpl il6 = new ILoanRepositoryImpl();
				System.out.println("The EMI for loan id: " + lid6 + " is " + il6.calculateEMI(lid6));

				break;
				
				
			case 7:
				System.out.println("You have entered 7: Calculate Loan Status");
				System.out.println("Enter Loan ID: ");
				int lid7 = sc.nextInt();
				
				ILoanRepositoryImpl il7 = new ILoanRepositoryImpl();
				il7.loanStatus(lid7);
				break;
				
				
			case 8:
				System.out.println("You have entered 8: Add Customer");
				Customer c = new Customer();
				
				c.addCus();
	
				break;
			case 9:
				System.out.println("You have entered 9: Exit");
				System.out.println("Thank you for using Loan Management System.");
				sc.close();
				choice = -1;
				break;

			default:
				System.out.println("Please enter a number from 1 to 9.");

			}

		}

	}

}
