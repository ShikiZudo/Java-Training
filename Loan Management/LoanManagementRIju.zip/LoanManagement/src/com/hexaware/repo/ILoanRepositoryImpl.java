package com.hexaware.repo;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.hexaware.util.DBUtil;

import java.util.Scanner;

import com.hexaware.entity.Loan;
import com.hexaware.exception.InvalidLoanException;

public class ILoanRepositoryImpl implements ILoanRepository{
	
	Scanner sc =new Scanner(System.in);
	
	public void applyLoan(Loan loan) throws Exception
	{
		
		// get details from user
		loan.addLoan();

	}
	
	 public float calculateInterest(int loanId) throws Exception {
		 
		 	String selectQuery = "SELECT Count(*) FROM loan WHERE lid= ?";
	        Connection con = DBUtil.getDBConn();
	        ResultSet resultSet = null;
	        PreparedStatement ps;
			try {
				ps = con.prepareStatement(selectQuery);
				ps.setInt(1, loanId);
		        resultSet = ps.executeQuery();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        resultSet.next();
	        int lc = resultSet.getInt(1);
	        
	        if (lc == 0) {
	            throw new InvalidLoanException();
	        }
	        
	        String selectQuery1 = "SELECT * FROM loan WHERE lid= ?";
	        PreparedStatement ps2 = con.prepareStatement(selectQuery1);
	        ps2.setInt(1, loanId);
	        ResultSet resultSet2 = ps2.executeQuery();
	         
	       
	       int pamt = 0;
	       float irate = 0;
	       int lterm = 0;
	       resultSet2.next();
	           
	          
	       pamt = resultSet2.getInt("pamt");
	       irate = resultSet2.getFloat("irate");
	       lterm = resultSet2.getInt("loan_term");
	          
	       return calculateInterest(pamt, irate, lterm);
	        
	        
	    }

	    public static float calculateInterest(int principalAmount, float interestRate, int loanTenure) {
	        return (float)(principalAmount * interestRate * loanTenure)/100; // Assuming interest rate is a percentage
	    }
	
	    
	    
	    
	public void loanStatus(int loanid){
	/*loanStatus(loanId): This method should display a message indicating that the loan is 
	approved or rejected based on credit score, if credit score above 650 loan approved else 
	rejected and should update in database*/
		
		String selectQuery1 = "select c.creditscore as cscore from customer c join loan l on c.cid = l.cid where lid = ?;";
		Connection con;
		try {
			//System.out.println("1");
			con = DBUtil.getDBConn();
			PreparedStatement ps = con.prepareStatement(selectQuery1);
	        ps.setInt(1, loanid);
	        ResultSet rs = ps.executeQuery();
	        rs.next();
	        int cscore = rs.getInt("cscore");
	        String l1="Approved";
	        String l2="Rejected";
	        
	        if(cscore>650)
	        {
	        	
	        	
	        	System.out.println("Loan Approved!!");
	        
	        	String selectQuery2 = "update loan set loan_status='"+l1+"' where lid = ? " ;
	        	
	        	PreparedStatement p2 = con.prepareStatement(selectQuery2);
		        p2.setInt(1, loanid);
		        p2.executeUpdate();
		        
	        }
	        else {
	        	
	        	System.out.println("Loan Rejected");
	        	String selectQuery3 = "update loan set loan_status='"+l2+"' where lid =? ";
	        	PreparedStatement ps3 = con.prepareStatement(selectQuery3);
	        	ps3.setInt(1, loanid);
		        ps3.executeUpdate(selectQuery3);
	        }
	        
	        
	        String selectQuery4 = "SELECT loan_status FROM loan WHERE lid= ?";
	        PreparedStatement ps4 = con.prepareStatement(selectQuery4);
	        ps4.setInt(1, loanid);
	        ResultSet rs4 = ps4.executeQuery();
	        rs4.next();
	        String lstatus = rs4.getString("loan_status");
	        System.out.println("The loan status for loan id: "+loanid+" is "+lstatus);
	        
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        
	
	}
	
	public float calculateEMI(int loanid) throws Exception{
		// check whether loanid exists
		
		//System.out.println("1");
		
		String selectQuery = "SELECT Count(*) FROM loan WHERE lid= ?";
        Connection con = DBUtil.getDBConn();
        PreparedStatement ps = con.prepareStatement(selectQuery);
        ps.setInt(1, loanid);
        ResultSet resultSet = ps.executeQuery();
        
       // System.out.println("2");
        resultSet.next();
        
        int lc = resultSet.getInt(1);
        
        if (lc == 0) {
            throw new InvalidLoanException(); 	// loan id does not exist
        }
        
        
        //System.out.println("3");
        String selectQuery1 = "SELECT * FROM loan WHERE lid= ?";
        
        PreparedStatement ps2 = con.prepareStatement(selectQuery1);
        ps2.setInt(1, loanid);
        ResultSet resultSet2 = ps2.executeQuery();
        //System.out.println("4");
        
       
        
        	int pamt = 0;
        	float irate = 0;
        	int lterm = 0;
        	resultSet2.next();
            
            
        	pamt = resultSet2.getInt("pamt");
            irate = resultSet2.getFloat("irate");
            lterm = resultSet2.getInt("loan_term");
            
            return (float)calculateEMI(pamt, irate, lterm);
           
        
	}
	public float calculateEMI(int P, float R, int N)
	{
		float emi;
		R=R/1200; // for monthly interest rate
		N=N*12; // for tenure in months
		emi= (float) ( P*R*( Math.pow( (1+R),N ) / ( Math.pow( (1+R) , N-1 ) ) ) );
		return emi;
	}
	
	public int loanRepayment(int loanid,float amt) throws Exception{

		//System.out.println("1");
        float emiAmount = calculateEMI(loanid);
        
        if (amt < emiAmount) {
            System.out.println("Payment rejected. Amount is less than one EMI.");
        }

        int noOfEmisPaid = (int) (amt/ emiAmount);

        System.out.println("YOur emi amount "+emiAmount);
        System.out.println("no of Emi = " +noOfEmisPaid+1);
      
        return noOfEmisPaid;
	}
	
	
	
    public void getAllLoan() {
     
        String selectQuery = "SELECT * FROM loan";

        try{
        	Connection con = DBUtil.getDBConn();
        	PreparedStatement ps = con.prepareStatement(selectQuery);
            ResultSet resultSet = ps.executeQuery();	 
        	

            while (resultSet.next()) 
            {
                
                System.out.println("Loan ID: " + resultSet.getInt("lid"));
                System.out.println("Customer ID: " + resultSet.getInt("cid"));
                System.out.println("Principal Amt: " + resultSet.getInt("pamt"));
                System.out.println("Interest Rate: " + resultSet.getFloat("irate"));
                System.out.println("Loan Tenure: " + resultSet.getInt("loan_term"));
                System.out.println("Loan Type: " + resultSet.getString("loan_type"));
                System.out.println("Loan Status: " + resultSet.getString("loan_status"));
                System.out.println();
 
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

 
	
	
	
	
	
	
	public void getLoanById(int loanid) {
		// search for loanid and print all details,
		// if loanid not found throw exception Invalidloanexp

        try
        {
        	// to check whether loanid exists
        	
    		String selectQuery = "SELECT Count(*) FROM loan WHERE lid= ?";
            Connection con = DBUtil.getDBConn();
            PreparedStatement ps = con.prepareStatement(selectQuery);
            ps.setInt(1, loanid);
            ResultSet resultSet1 = ps.executeQuery();
            resultSet1.next();
            int lc = resultSet1.getInt(1);
            
            if (lc == 0) {
                throw new InvalidLoanException(); 	// loan id does not exist
            }
    		
    		String selectQuery2 = "SELECT * FROM loan where lid=?";
       
        	PreparedStatement ps2 = con.prepareStatement(selectQuery2);
        	ps2.setInt(1, loanid);
            ResultSet resultSet = ps2.executeQuery();
            
            resultSet.next();
                
                System.out.println("Loan ID: " + resultSet.getInt("lid"));
                System.out.println("Customer ID: " + resultSet.getInt("cid"));
                System.out.println("Principal Amt: " + resultSet.getInt("pamt"));
                System.out.println("Interest Rate: " + resultSet.getFloat("irate"));
                System.out.println("Loan Tenure: " + resultSet.getInt("loan_term"));
                System.out.println("Loan Type: " + resultSet.getString("loan_type"));
                System.out.println("Loan Status: " + resultSet.getString("loan_status"));
                System.out.println();
          
            
        } catch (Exception e) {
            e.printStackTrace();
        }
	}


	}
	
