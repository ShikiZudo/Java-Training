package com.hexaware.repo;

import java.sql.SQLException;

import com.hexaware.entity.Loan;
import com.hexaware.exception.InvalidLoanException;

public interface ILoanRepository {
	void applyLoan(Loan loan) throws Exception ;
	
	float calculateInterest(int loanid) throws InvalidLoanException, SQLException, Exception;
	
	void loanStatus(int loanid);
	
	float calculateEMI(int loanid) throws Exception;
	
	float calculateEMI(int p ,float r, int n); // overloaded
	
	int loanRepayment(int loanid, float amt) throws Exception ;
	
	void getAllLoan();
	
	void getLoanById(int loanid);
}
