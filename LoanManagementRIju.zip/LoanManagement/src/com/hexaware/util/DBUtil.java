package com.hexaware.util;

import java.sql.Connection;
import java.sql.DriverManager;


public class DBUtil 
{
	
	public static Connection getDBConn() throws Exception{
		
		String url = "jdbc:mysql://localhost:3306/hexa1";    
	    String driverName = "com.mysql.cj.jdbc.Driver";   
	    String username = "root";   
	    String password = "root";
	    Connection con;
		
	    Class.forName(driverName); // dbname is hexa1 
		con =  DriverManager.getConnection(url,username,password);
		
		/*Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from empl");*/

		return con;
	}
}