package com.hexaware.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class DBPropertyUtil {

    public static String getConnectionString(String propertyFileName) {
        Properties properties = new Properties();
        try (FileInputStream fis = new FileInputStream(propertyFileName)) {
            properties.load(fis);
            return properties.getProperty("db.connectionString");
        } catch (IOException e) {
            e.printStackTrace();
            return null; // Handle the exception appropriately in a real-world scenario
        }
    }
}

/*
public static void main(String[] args) {
    // Example usage:
    String propertyFileName = "db.properties"; // Replace with your actual property file name
    String connectionString = DBPropertyUtil.getConnectionString(propertyFileName);

    if (connectionString != null) {
        Connection connection = DBConnUtil.getConnection(connectionString);
        if (connection != null) {
            System.out.println("Connected to the database!");
            // Perform database operations here
            // Remember to close the connection when done: connection.close();
        } else {
            System.out.println("Failed to connect to the database.");
        }
    } else {
        System.out.println("Failed to retrieve the connection string.");
    }
}
}*/
