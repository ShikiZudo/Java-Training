package com.hexaware.entity;

public class Loan {
	public Loan(int loanid, int cid, int pamt, float irate, int lterm, String ltype, String lstatus) {
		super();
		this.loanid = loanid;
		this.cid = cid;
		this.pamt = pamt;
		this.irate = irate;
		this.lterm = lterm;
		this.ltype = ltype;
		this.lstatus = lstatus;
	}
	public Loan() {
		// TODO Auto-generated constructor stub
	}
	public int getLoanid() {
		return loanid;
	}
	public void setLoanid(int loanid) {
		this.loanid = loanid;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public int getPamt() {
		return pamt;
	}
	public void setPamt(int pamt) {
		this.pamt = pamt;
	}
	public float getIrate() {
		return irate;
	}
	public void setIrate(float irate) {
		this.irate = irate;
	}
	public int getLterm() {
		return lterm;
	}
	public void setLterm(int lterm) {
		this.lterm = lterm;
	}
	public String getLtype() {
		return ltype;
	}
	public void setLtype(String ltype) {
		this.ltype = ltype;
	}
	public String getLstatus() {
		return lstatus;
	}
	public void setLstatus(String lstatus) {
		this.lstatus = lstatus;
	}
	public String toString(){//overriding the toString() method  
		  return loanid+" "+cid+" "+pamt+" "+irate+" "+lterm+" "+ltype+" "+lstatus; 
		 }
	
	int loanid;
	int cid;
	int pamt;
	float irate;
	int lterm;
	String ltype;
	String lstatus;

}





