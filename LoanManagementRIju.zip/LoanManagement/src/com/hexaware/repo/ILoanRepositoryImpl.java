package com.hexaware.repo;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.hexaware.util.DBUtil;

import java.util.Scanner;

import com.hexaware.entity.Loan;
import com.hexaware.exception.InvalidLoanException;

public class ILoanRepositoryImpl implements ILoanRepository{
	
	Scanner sc =new Scanner(System.in);
	
	public void applyLoan(Loan loan) throws Exception
	{
		
		// get details from user
		String padd = null,cmodel = null;
		int pval=0,cval=0;
		
		System.out.println("Enter Loan ID: ");   // set from 1000
		int loanid =sc.nextInt();
		loan.setLoanid(loanid);
		
		System.out.println("Enter Customer ID: ");	// set from 1
		int cid = sc.nextInt();
		loan.setCid(cid);
		
		System.out.println("Enter Principal Loan Amount: ");
		int pamt = sc.nextInt();
		loan.setPamt(pamt);
		
		System.out.println("Enter Loan interest rate per annum: ");
		float irate = sc.nextFloat();
		loan.setIrate(irate);
		
		System.out.println("Enter Loan term in years: ");
		int lterm = sc.nextInt();
		loan.setLterm(lterm);
		
		System.out.println("Enter loan type: Press 1 for Home Loan, Press 2 for Car Loan");
		int pr= sc.nextInt();
		String ltype = null;
		if(pr==1)
		{
			System.out.println("You have pressed 1: Home Loan:");
			loan.setLtype("HomeLoan");
			ltype="HomeLoan";
			System.out.println("Enter Property address");
			sc.nextLine(); // Consume the newline character
			padd = sc.nextLine();
			System.out.println("Enter Property Value");
			pval = sc.nextInt();
			
		}
		else if(pr==2)
		{
			System.out.println("You have pressed 2: Car Loan:");
			loan.setLtype("CarLoan");
			ltype="CarLoan";
			System.out.println("Enter Car Model");
			sc.nextLine(); // Consume the newline character
			cmodel = sc.nextLine();
			System.out.println("Enter Car Value");
			cval = sc.nextInt();
		}
		
		
		
		// set loan status as pending ... lstatus can be pending, rejected or approved
		String lstatus = "Pending";
		loan.setLstatus(lstatus);
		 
		// get confirmation from user
		System.out.println("Confirmation msg: Do you want to apply? enter 1 for Yes and 0 for No");
		int conf = sc.nextInt();
		
		if(conf==1) {
			
			
			Connection con = DBUtil.getDBConn();
			
	        PreparedStatement ps,ps2,ps3;
			
			String sql = "Insert into loan values("+loanid+","+cid+","+pamt+","+irate+","+lterm+",'"+ltype+"','"+lstatus+"')";
			ps = con.prepareStatement(sql);
	        ps.executeUpdate();
	        
	        if(pr==1)
	        {
	        //home loan
	        String sql2 = "Insert into  homeloan values("+loanid+","+cid+",'"+padd+"',"+pval+")";
			ps2 = con.prepareStatement(sql2);
	        ps2.executeUpdate();
	        }
	        if(pr==2) {
	        	//car loan
		        String sql3 = "Insert into carloan values("+loanid+","+cid+",'"+cmodel+"',"+cval+")";
				ps3 = con.prepareStatement(sql3);
		        ps3.executeUpdate();
	        }
	        
	        
			
	
		}
		else
			System.out.println("Loan apply cancelled");
		

	}
	
	 public float calculateInterest(int loanId) throws Exception {
		 
		 	String selectQuery = "SELECT Count(*) FROM loan WHERE lid= ?";
	        Connection con = DBUtil.getDBConn();
	        ResultSet resultSet = null;
	        PreparedStatement ps;
			try {
				ps = con.prepareStatement(selectQuery);
				ps.setInt(1, loanId);
		        resultSet = ps.executeQuery();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        resultSet.next();
	        int lc = resultSet.getInt(1);
	        
	        if (lc == 0) {
	            throw new InvalidLoanException();
	        }
	        
	        String selectQuery1 = "SELECT * FROM loan WHERE lid= ?";
	        PreparedStatement ps2 = con.prepareStatement(selectQuery1);
	        ps2.setInt(1, loanId);
	        ResultSet resultSet2 = ps2.executeQuery();
	         
	       
	       int pamt = 0;
	       float irate = 0;
	       int lterm = 0;
	       resultSet2.next();
	           
	          
	       pamt = resultSet2.getInt("pamt");
	       irate = resultSet2.getFloat("irate");
	       lterm = resultSet2.getInt("loan_term");
	          
	       return calculateInterest(pamt, irate, lterm);
	        
	        
	    }

	    public static float calculateInterest(int principalAmount, float interestRate, int loanTenure) {
	        return (float)(principalAmount * interestRate * loanTenure)/100; // Assuming interest rate is a percentage
	    }
	
	    
	    
	    
	public void loanStatus(int loanid){
	/*loanStatus(loanId): This method should display a message indicating that the loan is 
	approved or rejected based on credit score, if credit score above 650 loan approved else 
	rejected and should update in database*/
		
		String selectQuery1 = "select c.creditscore as cscore from customer c join loan l on c.cid = l.cid where lid = ?;";
		Connection con;
		try {
			//System.out.println("1");
			con = DBUtil.getDBConn();
			PreparedStatement ps = con.prepareStatement(selectQuery1);
	        ps.setInt(1, loanid);
	        ResultSet rs = ps.executeQuery();
	        rs.next();
	        int cscore = rs.getInt("cscore");
	        String l1="Approved";
	        String l2="Rejected";
	        
	        if(cscore>650)
	        {
	        	
	        	
	        	System.out.println("Loan Approved!!");
	        
	        	String selectQuery2 = "update loan set loan_status='"+l1+"' where lid = ? " ;
	        	
	        	PreparedStatement p2 = con.prepareStatement(selectQuery2);
		        p2.setInt(1, loanid);
		        p2.executeUpdate();
		        
	        }
	        else {
	        	
	        	System.out.println("Loan Rejected");
	        	String selectQuery3 = "update loan set loan_status='"+l2+"' where lid =? ";
	        	PreparedStatement ps3 = con.prepareStatement(selectQuery3);
	        	ps3.setInt(1, loanid);
		        ps3.executeUpdate(selectQuery3);
	        }
	        
	        
	        String selectQuery4 = "SELECT loan_status FROM loan WHERE lid= ?";
	        PreparedStatement ps4 = con.prepareStatement(selectQuery4);
	        ps4.setInt(1, loanid);
	        ResultSet rs4 = ps4.executeQuery();
	        rs4.next();
	        String lstatus = rs4.getString("loan_status");
	        System.out.println("The loan status for loan id: "+loanid+" is "+lstatus);
	        
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        
	
	}
	
	public float calculateEMI(int loanid) throws Exception{
		// check whether loanid exists
		
		//System.out.println("1");
		
		String selectQuery = "SELECT Count(*) FROM loan WHERE lid= ?";
        Connection con = DBUtil.getDBConn();
        PreparedStatement ps = con.prepareStatement(selectQuery);
        ps.setInt(1, loanid);
        ResultSet resultSet = ps.executeQuery();
        
       // System.out.println("2");
        resultSet.next();
        
        int lc = resultSet.getInt(1);
        
        if (lc == 0) {
            throw new InvalidLoanException(); 	// loan id does not exist
        }
        
        
        //System.out.println("3");
        String selectQuery1 = "SELECT * FROM loan WHERE lid= ?";
        
        PreparedStatement ps2 = con.prepareStatement(selectQuery1);
        ps2.setInt(1, loanid);
        ResultSet resultSet2 = ps2.executeQuery();
        //System.out.println("4");
        
       
        
        	int pamt = 0;
        	float irate = 0;
        	int lterm = 0;
        	resultSet2.next();
            
            
        	pamt = resultSet2.getInt("pamt");
            irate = resultSet2.getFloat("irate");
            lterm = resultSet2.getInt("loan_term");
            
            return (float)calculateEMI(pamt, irate, lterm);
           
        
	}
	public float calculateEMI(int P, float R, int N)
	{
		float emi;
		R=R/1200; // for monthly interest rate
		N=N*12; // for tenure in months
		emi= (float) ( P*R*( Math.pow( (1+R),N ) / ( Math.pow( (1+R) , N-1 ) ) ) );
		return emi;
	}
	
	public int loanRepayment(int loanid,float amt) throws Exception{

		//System.out.println("1");
        float emiAmount = calculateEMI(loanid);
        
        if (amt < emiAmount) {
            System.out.println("Payment rejected. Amount is less than one EMI.");
        }
        
        
        
        int noOfEmisPaid = (int) (amt/ emiAmount);

        //float remainingAmount = amt - (noOfEmisPaid * emiAmount);
        
        System.out.println("YOur emi amount "+emiAmount);
        System.out.println("no of Emi = " +noOfEmisPaid);
        //System.out.println("Amount Remaining = " +remainingAmount);
        
        /*// Update the table loan with amount 
        System.out.println("2");
        String selectQuery = "update loan set pamt=? where lid=? ;";
        Connection con = DBUtil.getDBConn();
        PreparedStatement ps = con.prepareStatement(selectQuery);
        ps.setFloat(1, remainingAmount);
        ps.setInt(2, loanid);
        ps.executeUpdate();*/

        return noOfEmisPaid;
	}
	
	
	
    public void getAllLoan() {
     
        String selectQuery = "SELECT * FROM loan";

        try{
        	Connection con = DBUtil.getDBConn();
        	PreparedStatement ps = con.prepareStatement(selectQuery);
            ResultSet resultSet = ps.executeQuery();	 
        	

            while (resultSet.next()) 
            {
                int lid = resultSet.getInt("lid");
                int cid = resultSet.getInt("cid");
                int pamt = resultSet.getInt("pamt");
                float irate = resultSet.getFloat("irate");
                int lterm = resultSet.getInt("loan_term");
                String ltype = resultSet.getString("loan_type");
                String lstatus = resultSet.getString("loan_status");
                
                System.out.println("Loan ID: " + lid);
                System.out.println("Customer ID: " + cid);
                System.out.println("Principal Amt: " + pamt);
                System.out.println("Interest Rate: " + irate);
                System.out.println("Loan Tenure: " + lterm);
                System.out.println("Loan Type: " + ltype);
                System.out.println("Loan Status: " + lstatus);
                System.out.println();
 
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

 
	
	
	
	
	
	
	public void getLoanById(int loanid) {
		// search for loanid and print all details,
		// if loanid not found throw exception Invalidloanexp

        try
        {
        	// to check whether loanid exists
        	
    		String selectQuery = "SELECT Count(*) FROM loan WHERE lid= ?";
            Connection con = DBUtil.getDBConn();
            PreparedStatement ps = con.prepareStatement(selectQuery);
            ps.setInt(1, loanid);
            ResultSet resultSet1 = ps.executeQuery();
            resultSet1.next();
            int lc = resultSet1.getInt(1);
            
            if (lc == 0) {
                throw new InvalidLoanException(); 	// loan id does not exist
            }
    		
    		String selectQuery2 = "SELECT * FROM loan where lid=?";
       
        	PreparedStatement ps2 = con.prepareStatement(selectQuery2);
        	ps2.setInt(1, loanid);
            ResultSet resultSet = ps2.executeQuery();
            
            resultSet.next();
           

 
                int lid = resultSet.getInt("lid");
                int cid = resultSet.getInt("cid");
                int pamt = resultSet.getInt("pamt");
                float irate = resultSet.getFloat("irate");
                int lterm = resultSet.getInt("loan_term");
                String ltype = resultSet.getString("loan_type");
                String lstatus = resultSet.getString("loan_status");
                
                System.out.println("Loan ID: " + lid);
                System.out.println("Customer ID: " + cid);
                System.out.println("Principal Amt: " + pamt);
                System.out.println("Interest Rate: " + irate);
                System.out.println("Loan Tenure: " + lterm);
                System.out.println("Loan Type: " + ltype);
                System.out.println("Loan Status: " + lstatus);
                System.out.println();
          
            
        } catch (Exception e) {
            e.printStackTrace();
        }
	}


	}
	
